package TreePackage;

import java.util.Iterator;

public class TreeTester {

	public static void main(String[] args) {
		
		// create the interior nodes (data will be set in setTree method)
		BinaryTreeInterface<Integer> node1 = new BinaryTree<Integer>();
		BinaryTreeInterface<Integer> node3 = new BinaryTree<Integer>();
		BinaryTreeInterface<Integer> node7 = new BinaryTree<Integer>();
		BinaryTreeInterface<Integer> node9 = new BinaryTree<Integer>();
		BinaryTreeInterface<Integer> node2 = new BinaryTree<Integer>();

		// create the leaves
		BinaryTreeInterface<Integer> node6 = new BinaryTree<Integer>(6);
		BinaryTreeInterface<Integer> node11 = new BinaryTree<Integer>(11);
		BinaryTreeInterface<Integer> node14 = new BinaryTree<Integer>(14);
		BinaryTreeInterface<Integer> node5 = new BinaryTree<Integer>(5);
		BinaryTreeInterface<Integer> node12 = new BinaryTree<Integer>(12);
		
		// create the root
		BinaryTree<Integer> numberTree = new BinaryTree<Integer>();

		// build the tree from the bottom up
		node7.setTree(7, node6, node11);
		node9.setTree(9, node14, null);
		node1.setTree(1, node7, node9);
		node2.setTree(2, node5, null);
		node3.setTree(3, node2, node12);
		numberTree.setTree(4, node1, node3);
		
		// print the traversals
		System.out.println("Pre-Order:");
		numberTree.preorderTraverse();

		System.out.println("In-Order:");
		numberTree.inorderTraverse();

		System.out.println("Post-Order:");
		numberTree.postorderTraverse();

		// find the sum of all numbers in the tree
		// note: for this task, you could use any of the three iterators
		Iterator <Integer> iterator = numberTree.getPreorderIterator();
		int sum = 0;
		while(iterator.hasNext()) {
			int nodeData = iterator.next();
			sum += nodeData;
		}
		System.out.println("Sum is " + sum);
		
	}

}
